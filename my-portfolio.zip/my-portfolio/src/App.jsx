
import './App.css'
import { useState } from 'react'

function App() {
  const [formStatus, setFormStatus] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  async function handleContactSubmit(event) {
    event.preventDefault()

    setFormStatus('')
    setIsSubmitting(true)

    const form = event.currentTarget
    const formData = new FormData(form)

    const payload = {
      name: formData.get('name'),
      email: formData.get('email'),
      message: formData.get('message')
    }

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      })

      const result = await response.json()

      if (!response.ok || !result.success) {
        throw new Error(
          result.message || 'Unable to save your message.'
        )
      }

      setFormStatus(result.message)
      form.reset()
    } catch (error) {
      setFormStatus(
        error.message || 'Something went wrong. Please try again.'
      )
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="portfolio">
      <nav className="navbar">
        <a href="#home" className="logo">
          Mansi Joshi<span>.</span>
        </a>

        <div className="nav-links">
          <a href="#home">Home</a>
          <a href="#about">About</a>
          <a href="#skills">Skills</a>
          <a href="#projects">Projects</a>
          <a href="#contact">Contact</a>
        </div>
      </nav>

      <main>
        {/* Hero Section */}
        <section className="hero" id="home">
          <div className="hero-content">
            <p className="eyebrow">PHP DEVELOPER</p>

            <h1>
              Hi, I'm <span>Mansi Joshi</span>
            </h1>

            <h2>I build reliable web applications.</h2>

            <p className="intro">
              I am a PHP Developer with 3 years of professional
              experience in web development. I work with Core PHP,
              CodeIgniter, MySQL and JavaScript to build and maintain
              web applications. I am open to PHP development
              opportunities in Germany and India.
            </p>

            <div className="hero-buttons">
              <a href="#projects" className="btn primary">
                View My Work
              </a>

              <a href="#contact" className="btn secondary">
                Contact Me
              </a>

              <a
                href="/api/cv/view"
                target="_blank"
                rel="noopener noreferrer"
                className="btn secondary"
              >
                <span aria-hidden="true">↓</span> View / Download CV
              </a>
            </div>
          </div>

          <div className="hero-card">
            <div className="code-icon">&lt;/&gt;</div>
            <h3>Developer Profile</h3>
            <p>Backend Development</p>
            <p>API Integration</p>
            <p>Database Management</p>
            <p>Problem Solving</p>
          </div>
        </section>

        {/* About Section */}
        <section className="section about" id="about">
          <p className="eyebrow">GET TO KNOW ME</p>

          <h2>About Me</h2>

          <p>
            I am Mansi Joshi, a PHP Developer with 3 years of
            professional experience in web development. My experience
            includes Core PHP, CodeIgniter, MySQL and JavaScript.
            I enjoy debugging issues, improving application
            functionality and developing reliable solutions. I am
            looking for opportunities where I can contribute my skills
            and continue growing as a developer in Germany or India.
          </p>
        </section>

        {/* Skills Section */}
        <section className="section" id="skills">
          <p className="eyebrow">WHAT I WORK WITH</p>

          <h2>My Skills</h2>

          <div className="skills-grid">
            {[
              'PHP',
              'CodeIgniter',
              'Laravel',
              'Yii2',
              'Docker',
              'MySQL',
              'JavaScript',
              'Reactjs Beginner',
              'Node.js Beginner',
              'Git',
              'Bitbucket',
              'REST APIs'
            ].map((skill) => (
              <div className="skill" key={skill}>
                {skill}
              </div>
            ))}
          </div>
        </section>

        {/* Projects Section */}
        <section id="projects" className="projects-section">
          <div className="projects-container">
            <div className="projects-header">
              <p className="projects-eyebrow">MY WORK</p>

              <h2>
                Featured Projects<span>.</span>
              </h2>

              <p className="projects-subtitle">
                A selection of web platforms and applications.
              </p>
            </div>

            <div className="projects-grid">
              <article className="project-card">
                <div className="project-top">
                  <span className="project-number">01</span>

                  <a
                    href="https://bookatable.mu/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="project-external-link"
                    aria-label="Visit BookaTable"
                  >
                    ↗
                  </a>
                </div>

                <h3>BookaTable</h3>

                <p className="project-description">
                  A restaurant discovery and reservation platform
                  for exploring restaurants and booking tables.
                </p>

                <div className="project-bottom">
                  <span className="project-category">
                    Restaurant Booking
                  </span>

                  <a
                    href="https://bookatable.mu/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="project-link"
                  >
                    Visit Website <span>↗</span>
                  </a>
                </div>
              </article>

              <article className="project-card">
                <div className="project-top">
                  <span className="project-number">02</span>

                  <a
                    href="https://dubisale.com/"https://stg.nao.fashion/
                    target="_blank"
                    rel="noopener noreferrer"
                    className="project-external-link"
                    aria-label="Visit DubiSale"
                  >
                    ↗
                  </a>
                </div>

                <h3>DubiSale</h3>

                <p className="project-description">
                  An online platform. Visit the website to explore
                  its features and services.
                </p>

                <div className="project-bottom">
                  <span className="project-category">
                    Web Platform
                  </span>

                  <a
                    href="https://dubisale.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="project-link"
                  >
                    Visit Website <span>↗</span>
                  </a>
                </div>
              </article>

              <article className="project-card">
                <div className="project-top">
                  <span className="project-number">03</span>

                  <a
                    href="https://jumpelite.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="project-external-link"
                    aria-label="Visit JumpElite"
                  >
                    ↗
                  </a>
                </div>

                <h3>JumpElite</h3>

                <p className="project-description">
                  An equestrian marketplace connecting buyers and
                  sellers in the show-jumping horse market.
                </p>

                <div className="project-bottom">
                  <span className="project-category">
                    Online Marketplace
                  </span>

                  <a
                    href="https://jumpelite.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="project-link"
                  >
                    Visit Website <span>↗</span>
                  </a>
                </div>
              </article>

              <article className="project-card">
                <div className="project-top">
                  <span className="project-number">04</span>

                  <a
                    href="https://academyanalytics.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="project-external-link"
                    aria-label="Visit Academy Analytics"
                  >
                    ↗
                  </a>
                </div>

                <h3>Academy Analytics</h3>

                <p className="project-description">
                  Explore the platform and its features. Add details
                  about your actual contribution to this project.
                </p>

                <div className="project-bottom">
                  <span className="project-category">
                    Web Application
                  </span>

                  <a
                    href="https://academyanalytics.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="project-link"
                  >
                    Visit Website <span>↗</span>
                  </a>
                </div>
              </article>
                            <article className="project-card">
                <div className="project-top">
                  <span className="project-number">05</span>

                  <a
                    href="https://stg.nao.fashion/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="project-external-link"
                    aria-label="Visit Nao Ecommerce"
                  >
                    ↗
                  </a>
                </div>

                <h3>Nao Ecommerce</h3>

                <p className="project-description">
                  An online platform. Visit the website to explore
                  its features and services.
                </p>

                <div className="project-bottom">
                  <span className="project-category">
                    Web Platform
                  </span>

                  <a
                    href="https://stg.nao.fashion/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="project-link"
                  >
                    Visit Website <span>↗</span>
                  </a>
                </div>
              </article>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="section contact">
          <p className="eyebrow">GET IN TOUCH</p>

          <h2>Let's Work Together</h2>

          <p className="contact-description">
            Looking for a PHP Developer? Have a project or job
            opportunity? Send me a message and I will get back to you.
          </p>

          <form
            className="contact-form"
            onSubmit={handleContactSubmit}
          >
            <div className="form-field">
              <label htmlFor="contact-name">Your Name</label>

              <input
                id="contact-name"
                type="text"
                name="name"
                placeholder="Enter your name"
                autoComplete="name"
                maxLength={100}
                required
              />
            </div>

            <div className="form-field">
              <label htmlFor="contact-email">Email Address</label>

              <input
                id="contact-email"
                type="email"
                name="email"
                placeholder="you@example.com"
                autoComplete="email"
                maxLength={254}
                required
              />
            </div>

            <div className="form-field">
              <label htmlFor="contact-message">Message</label>

              <textarea
                id="contact-message"
                name="message"
                placeholder="Tell me about the opportunity..."
                rows={5}
                maxLength={5000}
                required
              />
            </div>

            <button
              className="btn primary contact-submit"
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Saving...' : 'Send Message'}
              <span aria-hidden="true"> →</span>
            </button>

            {formStatus && (
              <p role="status" aria-live="polite">
                {formStatus}
              </p>
            )}
          </form>

          <p className="email-note">
            Prefer email?{' '}
            <a href="mailto:mansijoshi347@gmail.com">
              mansijoshi347@gmail.com
            </a>
          </p>
        </section>
      </main>

      {/* Footer */}
      <footer>
        <p>
          © {new Date().getFullYear()} Mansi Joshi. Built with React.
        </p>
      </footer>
    </div>
  )
}

export default App
