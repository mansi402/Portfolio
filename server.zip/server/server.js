
import express from "express";
import rateLimit from "express-rate-limit";
import db from "./db.js";
import path from "node:path";
import { fileURLToPath } from "node:url";


const currentDir = path.dirname(fileURLToPath(import.meta.url));

const cvPath = path.resolve(
  currentDir,
  "public/Mansi-Joshi-CV.pdf"
);

const insertCvEvent = db.prepare(`
  INSERT INTO cv_events (event_type, ip_address, user_agent)
  VALUES (?, ?, ?)
`);

function recordCvEvent(req, eventType) {
  try {
    const forwardedFor = req.headers["x-forwarded-for"];

    // Use the direct connection IP by default.
    // Only trust a proxy header after configuring a trusted proxy.
    const ipAddress = req.ip || null;

    const userAgent = String(req.get("user-agent") || "")
      .slice(0, 500) || null;

    insertCvEvent.run(eventType, ipAddress, userAgent);
  } catch (error) {
    // A tracking failure must not prevent the CV from opening.
    console.error("CV tracking failed:", error.message);
  }
}


const app = express();
const PORT = Number(process.env.PORT) || 5000;

app.disable("x-powered-by");
app.use(express.json({ limit: "10kb" }));


const contactLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  skip: () => process.env.NODE_ENV !== "production",
  message: {
    success: false,
    message: "Too many attempts. Please try again later."
  }
});


const insertMessage = db.prepare(`
  INSERT INTO contact_messages (name, email, message)
  VALUES (?, ?, ?)
`);

app.get("/api/health", (_req, res) => {
  console.log("3. Health route reached");

  res.status(200).json({
    success: true,
    message: "Portfolio API is running."
  });
});

app.post("/api/contact", contactLimiter, (req, res) => {
  const name =
    typeof req.body?.name === "string"
      ? req.body.name.trim()
      : "";

  const email =
    typeof req.body?.email === "string"
      ? req.body.email.trim()
      : "";

  const message =
    typeof req.body?.message === "string"
      ? req.body.message.trim()
      : "";

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!name || !email || !message) {
    return res.status(400).json({
      success: false,
      message: "Please fill in all fields."
    });
  }

  if (
    name.length > 100 ||
    email.length > 254 ||
    message.length > 5000 ||
    !emailPattern.test(email)
  ) {
    return res.status(400).json({
      success: false,
      message: "Please check your details and try again."
    });
  }

  try {
    insertMessage.run(name, email, message);

    return res.status(201).json({
      success: true,
      message: "Your message has been saved successfully!"
    });
  } catch (error) {
    console.error("Database save failed:", error.message);

    return res.status(500).json({
      success: false,
      message: "Unable to save your message. Please try again."
    });
  }
});

app.get("/api/cv/view", (req, res) => {
  recordCvEvent(req, "view");

  res.sendFile(cvPath, (error) => {
    if (error && !res.headersSent) {
      res.status(error.statusCode || 500).end();
    }
  });
});

app.get("/api/cv/download", (req, res) => {
  recordCvEvent(req, "download");

  res.download(cvPath, "Mansi-Joshi-CV.pdf", (error) => {
    if (error && !res.headersSent) {
      res.status(error.statusCode || 500).end();
    }
  });
});


app.get("/Mansi-Joshi-CV.pdf", (req, res) => {
  recordCvEvent(req, "view");

  res.sendFile(cvPath, (error) => {
    if (error && !res.headersSent) {
      res.status(error.statusCode || 500).end();
    }
  });
});



app.listen(PORT, () => {
  console.log(`Portfolio API running on http://localhost:${PORT}`);
});
